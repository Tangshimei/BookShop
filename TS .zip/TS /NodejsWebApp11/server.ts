var num = 13;
if (num % 3 == 0) {
console.log("oushu209test");
}
else {
console.log("jishu209test");
console.log("hi");


}